boot-stateless-auth
===================
Needs Gradle 2 and JDK 7

build with `gradle build`  
run with `gradle run`
